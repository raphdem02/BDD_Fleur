CREATE USER 'bozo'@'localhost:3306' IDENTIFIED BY 'bozo'; -- Création de bozo 
GRANT SELECT ON Fleurs.* TO 'bozo'@'localhost'; -- Accorder le fait d epouvoir lire les tables
FLUSH PRIVILEGES; -- Mise à jour des privilèges 
