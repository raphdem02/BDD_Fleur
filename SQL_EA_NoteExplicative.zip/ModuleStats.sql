-- MODULE STATS

-- Prix moyen du bouquet acheté 
SELECT AVG(Prix_total) as Prix_Moyen FROM Commande WHERE Type_commande = 'Standard';

-- Meilleurs clients du mois
-- Requête synchronisée (sous-requête) 
SELECT Id_client, SUM(Prix_total) as Total_mensuel
FROM Commande
WHERE MONTH(Date_commande) = MONTH(CURRENT_DATE()) AND YEAR(Date_commande) = YEAR(CURRENT_DATE())
GROUP BY Id_client
ORDER BY Total_mensuel DESC;
-- limit 1 pour garder que le premier 

-- Meilleurs clients de l'année
SELECT Id_client, SUM(Prix_total) as Total_annuel
FROM Commande
WHERE YEAR(Date_commande) = YEAR(CURRENT_DATE())
GROUP BY Id_client
ORDER BY Total_annuel DESC;
-- limit 1 pour garder que le premier

-- Bouquet standard qui a eu le plus de succès 
SELECT b.Id_Bouquet, b.Nom, COUNT(*) as Nombre_commandes
FROM Commande_Bouquet cb
JOIN Commande c ON cb.Id_Commande = c.Id_Commande
JOIN Bouquet b ON cb.Id_Bouquet = b.Id_Bouquet
WHERE c.Type_commande = 'Standard'
GROUP BY b.Id_Bouquet, b.Nom
ORDER BY Nombre_commandes DESC;
-- Limit 1 pour le premier

-- Magasin ayant généré le plus de chiffre d'affaires 
SELECT Id_Magasin, SUM(Prix_total) as Chiffre_affaires
FROM Commande
GROUP BY Id_Magasin
ORDER BY Chiffre_affaires DESC
LIMIT 1;

-- Requete Union
-- 5 bouquets les plus vendus / 5 produits les plus vendus 
SELECT * FROM (
  SELECT 'Bouquet' as Type, b.Id_Bouquet as Id, b.Nom, SUM(cb.Quantite) as Quantite_vendue
  FROM Commande_Bouquet cb
  JOIN Bouquet b ON cb.Id_Bouquet = b.Id_Bouquet
  GROUP BY b.Id_Bouquet, b.Nom
  ORDER BY Quantite_vendue DESC
  LIMIT 5
) AS Bouquets

UNION

SELECT * FROM (
  SELECT 'Produit' as Type, p.Id_Produit as Id, p.Nom, SUM(cp.Quantite) as Quantite_vendue
  FROM Commande_Produit cp
  JOIN Produit p ON cp.Id_Produit = p.Id_Produit
  GROUP BY p.Id_Produit, p.Nom
  ORDER BY Quantite_vendue DESC
  LIMIT 5
) AS Produits

ORDER BY Quantite_vendue DESC;

-- Requete auto-jointure : Cette requête compare chaque ligne de la table 'Client' (alias A) à chaque autre ligne (alias B) pour voir si elles ont le même niveau de fidélité
SELECT A.Nom, B.Nom 
FROM Client A, Client B
WHERE A.fidelite = B.fidelite AND A.Id_client != B.Id_client;

-- Requete synchronisée (sous-requete corrélée)
-- trouver tous les clients qui ont passé une commande dont le Prix_total est supérieur à la moyenne des prix de toutes les commandes passées.
SELECT c.Nom, c.Prenom
FROM Client c
WHERE EXISTS (
    SELECT 1
    FROM Commande com
    WHERE com.Id_Client = c.Id_client
    AND com.Prix_total > (
        SELECT AVG(Prix_total)
        FROM Commande
    )
);




