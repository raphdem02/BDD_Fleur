SET @Id_Commande = 	1; -- Remplacez 1 par l'identifiant de la commande concernée
SET @Seuil_Alerte = 91; -- Remplacez 91 par le seuil d'alerte 

-- Mise à jour du stock pour une commande personalisé / PRODUIT PAR PRODUIT 
UPDATE Stock s
JOIN Commande_Produit cp ON s.Id_Produit = cp.Id_Produit
JOIN Commande c ON s.Id_Magasin = c.Id_Magasin
SET s.Quantite = s.Quantite - cp.Quantite
WHERE cp.Id_Commande = @Id_Commande AND c.Id_Commande = @Id_Commande;

-- Visualisation mis à jour 
SELECT s.Id_Magasin, s.Id_Produit, p.Nom AS 'Nom du produit', s.Quantite AS 'Quantite en stock' -- 'Nom du produit'
FROM Stock s
JOIN Produit p ON s.Id_Produit = p.Id_Produit
ORDER BY s.Id_Magasin, s.Id_Produit;


-- Acutalisation des stock apres COMMAND STANDARD ORDER / COMMANDE BOUquet
SELECT @last_id_commande AS Id_Commande, @bouquet_id AS Id_Bouquet;

UPDATE Stock s
JOIN Bouquet_Produit bp ON s.Id_Produit = bp.Id_Produit
JOIN Commande_Bouquet cb ON cb.Id_Bouquet = bp.Id_Bouquet
JOIN Commande c ON s.Id_Magasin = c.Id_Magasin AND c.Id_Commande = cb.Id_Commande
SET s.Quantite = s.Quantite - 1
WHERE cb.Id_Commande = @Id_Commande AND cb.Id_Bouquet = @Id_Bouquet AND c.Id_Commande = @Id_Commande;


-- Vérification du seuil d'alerte pour les produits du magasin concerné
SELECT s.Id_Magasin, s.Id_Produit, s.Quantite, p.Nom AS 'Nom du produit', s.Seuil_alerte -- 'Nom du produit'
FROM Stock s
JOIN Produit p ON s.Id_Produit = p.Id_Produit
JOIN Commande c ON s.Id_Magasin = c.Id_Magasin
WHERE c.Id_Commande = @Id_Commande AND s.Quantite <= @Seuil_Alerte;  -- Affihcer un message en c#

-- Consulter les stocks de tout les magasins en même temps 
SELECT s.Id_Magasin, m.Nom AS 'Nom du magasin', s.Id_Produit, p.Nom AS 'Nom du produit', s.Quantite
FROM Stock s
JOIN Magasin m ON s.Id_Magasin = m.Id_Magasin
JOIN Produit p ON s.Id_Produit = p.Id_Produit
ORDER BY s.Id_Magasin, s.Id_Produit;


-- Procédure commande standard --> i.e on commande un bouquet (elle est nouvelle on fait l'état tout seul si <3jours VINV sinon non

DELIMITER //

CREATE PROCEDURE CreateStandardOrder1(
    IN p_Id_Client INT, 
    IN p_Id_Magasin INT, 
    IN p_Date_commande DATE, 
    IN p_Adresse_livraison VARCHAR(255), 
    IN p_Message TEXT, 
    IN p_Date_livraison_voulue DATE, 
    IN p_Type_commande ENUM('Standard', 'Personalisee')
)
BEGIN
  DECLARE v_BouquetPrice DECIMAL(10,2);
  DECLARE v_ClientFidelity ENUM('Or', 'Bronze', 'Aucun');
  DECLARE v_Reduction DECIMAL(4,2);
  DECLARE v_Etat_commande ENUM('VINV','CC','CPAV','CAL','CL');
  
  -- Récupérer le prix du bouquet
  SELECT Prix INTO v_BouquetPrice
  FROM Bouquet
  WHERE Nom = p_Message;

  -- Récupérer la fidélité du client
  SELECT fidelite INTO v_ClientFidelity
  FROM Client
  WHERE Id_client = p_Id_Client;
  
  -- Déterminer la réduction en fonction de la fidélité du client
  IF v_ClientFidelity = 'Or' THEN
    SET v_Reduction = 0.15;
  ELSEIF v_ClientFidelity = 'Bronze' THEN
    SET v_Reduction = 0.05;
  ELSE
    SET v_Reduction = 0;
  END IF;
  
  -- Appliquer la réduction (si elle existe) au prix du bouquet
  SET v_BouquetPrice = v_BouquetPrice * (1 - v_Reduction);

  -- Déterminer l'état de la commande en fonction de la différence entre la date de livraison voulue et la date de commande
  IF DATEDIFF(p_Date_livraison_voulue, p_Date_commande) < 3 THEN
    SET v_Etat_commande = 'VINV';
  ELSE
    SET v_Etat_commande = 'CC';
  END IF;

  -- Insérer la nouvelle commande dans la table Commande avec le message contenant le nom du bouquet et son prix
  INSERT INTO Commande (Id_Client, Id_Magasin, Date_commande, Adresse_livraison, message, Date_livraison_voulue, Etat_commande, Type_commande, Prix_total, Reduction, Prix_maximum)
  VALUES (p_Id_Client, p_Id_Magasin, p_Date_commande, p_Adresse_livraison, p_Message, p_Date_livraison_voulue, v_Etat_commande, p_Type_commande, v_BouquetPrice, v_Reduction, NULL);

  -- Récupérer l'Id_Commande généré automatiquement lors de l'insertion
  SET @last_id_commande = LAST_INSERT_ID();

  -- Récupérer l'Id_Bouquet correspondant au nom du bouquet renseigné dans le message
  SELECT Id_Bouquet INTO @bouquet_id
  FROM Bouquet
  WHERE Nom = p_Message;

  -- Insérer une nouvelle entrée dans la table Commande_Bouquet avec l'Id_Commande et l'Id_Bouquet récupérés
  INSERT INTO Commande_Bouquet (Id_Commande, Id_Bouquet, Quantite)
  VALUES (@last_id_commande, @bouquet_id, 1);
END//

DELIMITER ;


-- Test de la procédure CreateStandardOrder
CALL CreateStandardOrder(1, 1, '2023-05-02', '15 rue des Lilas, Paris', 'L\'Amoureux', '2023-05-08', 'Standard'); -- à la place de l'amoureux tu peux mettre celui renseigné par la cliente 
SELECT * FROM Commande WHERE message LIKE '%L\'Amoureux%';


-- Commande personalisé

DELIMITER //

CREATE PROCEDURE CreatePersonalizedOrder(
    IN p_Id_Client INT,
    IN p_Id_Magasin INT,
    IN p_Date_commande DATE,
    IN p_Adresse_livraison VARCHAR(255),
    IN p_Message TEXT,
    IN p_Date_livraison_voulue DATE,
    IN p_Etat_commande ENUM('VINV','CC','CPAV','CAL','CL'),
    IN p_Type_commande ENUM('Standard', 'Personalisee'),
    IN p_Prix_maximum DECIMAL(10,2)
)
BEGIN
  DECLARE v_ClientFidelity ENUM('Or', 'Bronze', 'Aucun');
  DECLARE v_Reduction DECIMAL(4,2);

  -- Récupérer la fidélité du client
  SELECT fidelite INTO v_ClientFidelity
  FROM Client
  WHERE Id_client = p_Id_Client;
  
  -- Déterminer la réduction en fonction de la fidélité du client
  IF v_ClientFidelity = 'Or' THEN
    SET v_Reduction = 0.15;
  ELSEIF v_ClientFidelity = 'Bronze' THEN
    SET v_Reduction = 0.05;
  ELSE
    SET v_Reduction = 0;
  END IF;
  
  -- Insérer la nouvelle commande dans la table Commande avec le message contenant les éléments souhaités et le prix maximum
  INSERT INTO Commande (Id_Client, Id_Magasin, Date_commande, Adresse_livraison, message, Date_livraison_voulue, Etat_commande, Type_commande, Prix_total, Reduction, Prix_maximum)
  VALUES (p_Id_Client, p_Id_Magasin, p_Date_commande, p_Adresse_livraison, p_Message, p_Date_livraison_voulue, p_Etat_commande, p_Type_commande, NULL, v_Reduction, p_Prix_maximum);

  -- Récupérer l'Id_Commande généré automatiquement lors de l'insertion
  SET @last_id_commande = LAST_INSERT_ID();

  -- Traiter le message pour récupérer les produits et leurs quantités
  -- (Cela nécessite une fonction personnalisée pour extraire les produits et les quantités du message, 
  -- qui n'est pas implémentée ici car cela sort du champ d'application de MySQL)
  -- INSERT INTO Commande_Produit (Id_Commande, Id_Produit, Quantite) les valeurs extraites du message

END//

DELIMITER ;

-- Test Commande Personalisé
CALL CreatePersonalizedOrder(1, 1, '2023-05-02', '15 rue des Lilas, Paris', 'Rose rouge; 10, Vase; 1', '2023-05-04', 'VINV', 'Personalisee', 100);
SELECT * from Commande;

-- Note dans la commande perso manque le prix --> trouver un moyen avec le stock de recuper le prix clé privée de id_produit