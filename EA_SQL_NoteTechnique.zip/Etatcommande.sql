-- Nombre de commande pour toutes les dates
SELECT DATE(Date_commande) AS CommandeDate, COUNT(*) AS NombreDeCommandes FROM Commande GROUP BY CommandeDate ORDER BY CommandeDate;

-- Commande par date / pour le calendrier 
SELECT * FROM Commande WHERE DATE(Date_commande) = '2023-05-02';

-- Consulter l'état de la commande et le changer à la mano
SELECT Id_Commande, Type_commande, Date_commande, Date_livraison_voulue, message, Etat_commande
FROM Commande
WHERE Id_Commande = 1; -- Remplacez 1 par l'ID de commande souhaité

-- Update les états de commandes / à rentrer à la main sur c# (pense que dans les commandes standards on doit changer à la mano pour cc sur condition ou pour mettre en CL à la fin 
SET @client_id = 1;
UPDATE Commande SET Etat_commande = 'CC' WHERE Id_Commande = @client_id; -- Remplacez 1 par l'ID de commande souhaité
UPDATE Commande SET Etat_commande = 'VINV' WHERE Id_Commande = @client_id;
UPDATE Commande SET Etat_commande = 'CPAL' WHERE Id_Commande = @client_id;
UPDATE Commande SET Etat_commande = 'CAL' WHERE Id_Commande = @client_id;	
UPDATE Commande SET Etat_commande = 'CL' WHERE Id_Commande = @client_id;
